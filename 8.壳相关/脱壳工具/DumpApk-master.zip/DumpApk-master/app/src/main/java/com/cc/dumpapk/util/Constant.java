package com.cc.dumpapk.util;

public class Constant {
	
	public static String FILESAVEPATH = "XAndReverseTool";

}
