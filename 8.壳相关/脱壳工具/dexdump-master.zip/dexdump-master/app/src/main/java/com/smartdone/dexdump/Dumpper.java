package com.smartdone.dexdump;

/**
 * Created by smartdone on 2017/7/1.
 */

public class Dumpper {
    public static native void dump();
}
