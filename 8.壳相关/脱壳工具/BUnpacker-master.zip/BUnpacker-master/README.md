BUnpacker
===  
          
简介
===

*BUnpacker*是一款Android脱壳工具
*TUnpacker* is an Android unpack tool.

使用方法
===
	python bunpacker.py jiagu.apk
	
工具截图
===
 ![image](https://github.com/DrizzleRisk/BUnpacker/blob/master/screenshot.png)

必读事项
===
	1.本代码仅适用于特定的加固方式 (BB)
	2.本代码仅供安全研究及授权测试使用，如用于非法用途，后果自负
	3.运行本代码前需要确保连接Android测试设备或虚拟机，并确保Android系统已root
	4.如Dump等待时间过长或Dump失败，请多试几次！
	
工具集（分别适用于不同加固）
===
drizzleDumper <https://github.com/DrizzleRisk/drizzleDumper>

TUnpacker <https://github.com/DrizzleRisk/TUnpacker>

BUnpacker <https://github.com/DrizzleRisk/BUnpacker>
