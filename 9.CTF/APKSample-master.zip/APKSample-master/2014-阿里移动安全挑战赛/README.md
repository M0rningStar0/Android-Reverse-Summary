WriteUp:

AliCrackme_1.apk：[https://www.bodkin.ren/index.php/archives/602](https://www.bodkin.ren/index.php/archives/602)

AliCrackme_2.apk：[https://www.bodkin.ren/index.php/archives/643](https://www.bodkin.ren/index.php/archives/643)