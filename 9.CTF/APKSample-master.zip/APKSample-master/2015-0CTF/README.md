WriteUp:

1、EasyRe.apk：[https://www.bodkin.ren/index.php/archives/606](https://www.bodkin.ren/index.php/archives/606)

其他参考WP：

[http://www.purpleroc.com/MD/2015-03-31@0CTF_WriteUp.html](http://www.purpleroc.com/MD/2015-03-31@0CTF_WriteUp.html)

[http://eternalsakura13.com/2018/02/10/easyre](http://eternalsakura13.com/2018/02/10/easyre)